/*
 ============================================================================
 Name        : aula-13-2.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

const char* ARQUIVO_FIXO = "./meu_arquivo_querido.virus";

int main(void) {
	int arq;

	arq = open(
			// caminho para o arquivo
			ARQUIVO_FIXO,
			//modo de acesso (R, W, RW) + flags
			O_RDRW | O_CREAT,
			// permissão de criaçãos
			S_IRUSR | S_IWUSR );

	int res = read(arq, buffer, tam_buffer);

	return EXIT_SUCCESS;
}
