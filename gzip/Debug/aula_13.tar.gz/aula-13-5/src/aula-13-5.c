/*
 ============================================================================
 Name        : aula-13-5.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int x[2];
	char buffer[10];
	int wr, rd;

	if (pipe(x) < 0)//trat erro

//		x[0]; extremidade de leitura (read)
//		x[1]; extremidade de escrita (write)


	rd = read(x[0], buffer, 10);
	wr = write(x[1], "ola", 4);

	printf("leu %d: %s", buffer);

	return EXIT_SUCCESS;
}
