/*
 ============================================================================
 Name        : aula-13-3.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(void) {
	const char* FILENAME = "umarquivo.txt";
	int fd = open(FILENAME, O_RDONLY| O_CLOEXEC);

	dup2(fd, STDIN_FILENO); //duplica um descritor para um número, neste caso para o numero 0
//	close(fd); não é necessário devido ao O_CLOEXEC

//	carregar programa que ira processar sua
//	entrada padrao, sem saber que é um arquivo
	execlp("wc", "wc", "-l", NULL);


//	tratamento de erro
	return EXIT_SUCCESS;
}
