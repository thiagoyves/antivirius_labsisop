/*
 ============================================================================
 Name        : aula-13-1.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>

struct t{
	volatile sig_atomic_t* contador_global;
};

int main(void) {
	volatile sig_atomic_t c;
	struct t trabalho;
	trabalho.contador_global = &c;

	int v = 10;
	int* pv = &v;

	(*pv)++;
	return 0;

}

void* thr(struct t* param){
	*(param->contador_global) += 1;
//	pthread_exit(NULL);
	return NULL;
}
