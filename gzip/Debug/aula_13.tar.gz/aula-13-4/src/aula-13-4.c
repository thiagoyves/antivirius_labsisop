/*
 ============================================================================
 Name        : aula-13-4.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(void) {
	int out = open("saida.txt",O_WRONLY, S_IRUSR);
	dup2(out, STDOUT_FILENO);
	close(out);
	execlp("date", "date", NULL);
	return EXIT_SUCCESS;
}
